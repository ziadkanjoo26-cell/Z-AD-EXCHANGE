package com.ziadexchange.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable periodicRefresh = new Runnable() {
        @Override public void run() { if (web != null) { web.evaluateJavascript("refresh()", null); handler.postDelayed(this, 15 * 60 * 1000L); } }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidRates");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        handler.postDelayed(periodicRefresh, 15 * 60 * 1000L);
    }
    private class Bridge {
        @JavascriptInterface public void refresh() {
            executor.execute(() -> {
                HttpURLConnection c = null;
                try {
                    URL url = new URL("https://lirascope.syria-cloud.sy/api/v1/rates/latest?currencies=USD,EUR,TRY&lang=ar");
                    c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(12000);
                    c.setRequestProperty("Accept", "application/json");
                    int code = c.getResponseCode();
                    if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder b = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null) b.append(line);
                    r.close();
                    JSONObject root = new JSONObject(b.toString());
                    JSONArray market = root.optJSONArray("marketRates");
                    JSONArray effective = root.optJSONArray("effectiveRates");
                    if (market == null && effective == null) throw new Exception("لم تصل بيانات السوق");
                    JSONObject out = new JSONObject(); out.put("timestampUtc", root.optString("timestampUtc", ""));
                    JSONObject byCurrency = new JSONObject();
                    if (market != null) for (int i=0; i<market.length(); i++) {
                        JSONObject x = market.getJSONObject(i); String cur = x.optString("currency", "");
                        if (cur.equals("USD") || cur.equals("EUR") || cur.equals("TRY")) byCurrency.put(cur, x);
                    }
                    // Fill currencies absent from the direct market list from the provider's effective rates.
                    if (effective != null) for (int i=0; i<effective.length(); i++) {
                        JSONObject x = effective.getJSONObject(i); String cur = x.optString("currency", "");
                        if ((cur.equals("USD") || cur.equals("EUR") || cur.equals("TRY")) && !byCurrency.has(cur)) byCurrency.put(cur, x);
                    }
                    JSONArray filtered = new JSONArray();
                    for (String cur : new String[]{"USD", "EUR", "TRY"}) if (byCurrency.has(cur)) filtered.put(byCurrency.getJSONObject(cur));
                    out.put("rates", filtered);
                    String js = "window.onRates(" + JSONObject.quote(out.toString()) + ", null)";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                } catch (Exception e) {
                    String err = e.getMessage() == null ? "تعذر جلب الأسعار" : e.getMessage();
                    String js = "window.onRates(null, " + JSONObject.quote(err) + ")";
                    runOnUiThread(() -> web.evaluateJavascript(js, null));
                } finally { if (c != null) c.disconnect(); }
            });
        }
    }
    @Override protected void onResume() { super.onResume(); if (web != null) web.evaluateJavascript("refresh()", null); }
    @Override protected void onDestroy() { handler.removeCallbacks(periodicRefresh); executor.shutdownNow(); if (web != null) web.destroy(); super.onDestroy(); }
}
